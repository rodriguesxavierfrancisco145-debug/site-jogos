# MOZ MARKET 2.0 🇲🇿

Marketplace inicial com Next.js, Vercel e Supabase.

## Funcionalidades incluídas
- Página pública com anúncios aprovados e dentro da validade.
- Registo/login de vendedores por email e palavra-passe.
- Área do vendedor com os seus anúncios.
- Submissão de anúncios com imagem, categoria, preço e WhatsApp.
- Planos configuráveis: 100 MT/7 dias, 200 MT/15 dias, 350 MT/30 dias.
- Estado pendente até revisão humana do pagamento e conteúdo.
- Painel de administração protegido por perfil `admin`.
- Imagens num bucket privado do Supabase.
- Row Level Security (RLS) para limitar o acesso aos dados.

## 1. Criar projeto Supabase
1. Cria um projeto no Supabase.
2. Abre SQL Editor e executa `supabase/schema.sql`.
3. Em Authentication > URL Configuration, configura a URL local e a URL pública da Vercel.
4. Copia Project URL e anon/public key para `.env.local`.

Exemplo `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://TEU-PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=TUA_CHAVE_ANON
```
Nunca coloques `service_role` no frontend, no GitHub ou em variáveis `NEXT_PUBLIC_`.

## 2. Executar no computador
Requer Node.js 20.9 ou superior.

```bash
npm install
npm run dev
```
Abre http://localhost:3000

## 3. Criar o administrador
1. Regista uma conta normal no site.
2. Confirma o email, se a confirmação estiver ativa.
3. No SQL Editor do Supabase, executa, substituindo pelo teu email:
```sql
update public.profiles
set role = 'admin'
where email = 'teu-email@exemplo.com';
```
4. Abre `/admin` já com sessão iniciada.

Apenas o proprietário do projeto deve promover contas a administrador.

## 4. Publicar na Vercel
1. Envia os ficheiros deste projeto para um repositório privado no GitHub.
2. Na Vercel, importa esse repositório.
3. Adiciona `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` em Environment Variables.
4. Faz Deploy.
5. Adiciona o domínio Vercel em Supabase > Authentication > URL Configuration e configura Site URL/redirect URLs.

## 5. Pagamentos
Esta versão NÃO cobra automaticamente nem confirma M-Pesa/e-Mola.
O vendedor informa uma referência de transação. Um administrador deve confirmar o pagamento no canal oficial do fornecedor antes de aprovar.
Não recolhas PIN, OTP, palavra-passe ou códigos secretos de clientes.
Para automatizar pagamentos, contrata uma integração oficial de pagamentos que forneça API/webhooks. A confirmação deve ser feita no servidor, validando assinatura do webhook, valor, moeda, referência e estado da transação. Nunca confies apenas no texto enviado pelo navegador.

## 6. Antes de abrir ao público
- Configura email de confirmação e recuperação de palavra-passe.
- Configura CAPTCHA/rate limiting para travar spam.
- Adiciona termos, política de privacidade, regras de anúncios e contactos.
- Valida vendedores e anúncios, e cria processo de denúncia.
- Faz backup e testa RLS com contas diferentes.
- Configura eliminação segura de imagens órfãs.
- Adiciona um processo agendado para marcar anúncios expirados como `expired`. A página pública já deixa de os mostrar pela data `expires_at`.

## Limitações desta versão
- Pagamentos são verificados manualmente.
- O vendedor pode enviar a referência, mas isso não prova que pagou.
- A listagem pública mostra dados básicos; ainda não existe página individual do anúncio nem edição/renovação.
- Para uso comercial, recomenda-se revisão técnica e de segurança antes do lançamento.
