-- Executar no SQL Editor do projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'seller' check (role in ('seller','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles(id,email,role)
  values(new.id,new.email,'seller')
  on conflict(id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.ads (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check(length(title) between 1 and 90),
  category text not null,
  description text not null check(length(description) <= 1500),
  price numeric(12,2) not null check(price >= 0),
  phone text not null,
  plan_id text not null check(plan_id in ('basic','standard','premium')),
  amount_paid integer not null check(amount_paid in (100,200,350)),
  payment_reference text not null,
  image_path text,
  status text not null default 'pending' check(status in ('pending','approved','rejected','expired')),
  created_at timestamptz not null default now(),
  approved_at timestamptz,
  expires_at timestamptz
);

alter table public.profiles enable row level security;
alter table public.ads enable row level security;

create policy "profiles read own" on public.profiles
for select to authenticated using (auth.uid() = id);
-- Sem policy de update/insert para utilizadores: role não pode ser alterada pelo próprio.

create policy "public read active approved ads" on public.ads
for select to anon, authenticated using (status='approved' and expires_at > now());

create policy "seller read own ads" on public.ads
for select to authenticated using (seller_id=auth.uid());

create policy "seller create own pending ads" on public.ads
for insert to authenticated with check (
  seller_id=auth.uid() and status='pending' and expires_at is null and approved_at is null
);

-- Atualizações administrativas são executadas pela API usando a sessão autenticada.
-- Adicionar policy de admin com verificação em profiles:
create policy "admin read all ads" on public.ads
for select to authenticated using (
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);
create policy "admin update ads" on public.ads
for update to authenticated using (
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
) with check (
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);

-- Storage privado: os anúncios só ficam acessíveis via URL assinada.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('ad-images','ad-images',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do nothing;

create policy "seller upload own ad images" on storage.objects
for insert to authenticated with check (
  bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text
);
create policy "seller read own images" on storage.objects
for select to authenticated using (
  bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text
);
create policy "admin read ad images" on storage.objects
for select to authenticated using (
  bucket_id='ad-images' and exists(
    select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'
  )
);

-- Após criares a tua conta, promove-a manualmente pelo SQL Editor:
-- update public.profiles set role='admin' where email='O_TEU_EMAIL';
