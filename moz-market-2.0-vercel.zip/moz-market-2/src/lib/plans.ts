export const PLANS = {
  basic: { name: "Básico", price: 100, days: 7 },
  standard: { name: "Standard", price: 200, days: 15 },
  premium: { name: "Premium", price: 350, days: 30 }
} as const;

export type PlanId = keyof typeof PLANS;
