import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "MOZ MARKET 🇲🇿",
  description: "O mercado digital de Moçambique. Comprar. Vender. Crescer."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt">
      <body>
        <header className="topbar">
          <Link href="/" className="brand">MOZ MARKET <span>🇲🇿</span></Link>
          <nav>
            <Link href="/">Início</Link>
            <Link href="/publicar">Publicar anúncio</Link>
            <Link href="/conta">Minha conta</Link>
          </nav>
        </header>
        <main>{children}</main>
        <footer>MOZ MARKET 🇲🇿 · Comprar. Vender. Crescer.</footer>
      </body>
    </html>
  );
}
