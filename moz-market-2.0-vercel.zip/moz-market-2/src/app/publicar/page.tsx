"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { PLANS, PlanId } from "@/lib/plans";

export default function Publish() {
  const supabase=createClient();
  const [plan,setPlan]=useState<PlanId>("basic");
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");
  const [form,setForm]=useState({title:"",category:"",description:"",price:"",phone:"",payment_reference:""});
  const [image,setImage]=useState<File|null>(null);

  async function submit(e:React.FormEvent){
    e.preventDefault();setBusy(true);setMessage("");
    try{
      const {data:{user}}=await supabase.auth.getUser();
      if(!user){setMessage("Entra na tua conta antes de publicar.");return;}
      const body=new FormData();
      Object.entries(form).forEach(([k,v])=>body.append(k,v));
      body.append("plan",plan);
      if(image)body.append("image",image);
      const res=await fetch("/api/ads",{method:"POST",body});
      const json=await res.json();
      if(!res.ok)throw new Error(json.error||"Não foi possível enviar.");
      setMessage("Pedido enviado! O anúncio ficará pendente até o pagamento e o conteúdo serem verificados.");
      setForm({title:"",category:"",description:"",price:"",phone:"",payment_reference:""});
      setImage(null);
    }catch(err:any){setMessage(err.message)}
    finally{setBusy(false)}
  }
  return <section className="card" style={{maxWidth:720,margin:"20px auto"}}>
    <h1>📦 Publicar anúncio</h1>
    <p className="muted">Todos os anúncios passam por verificação antes de aparecerem publicamente.</p>
    <form onSubmit={submit}>
      <label>Título do anúncio</label><input required maxLength={90} value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
      <label>Categoria</label><select required value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option value="">Escolher categoria</option>{["Telemóveis","Computadores","Automóveis","Imóveis","Moda","Alimentação","Serviços","Outros"].map(x=><option key={x}>{x}</option>)}</select>
      <label>Descrição</label><textarea required maxLength={1500} value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
      <div className="row"><div><label>Preço (MT)</label><input type="number" min="0" required value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></div><div><label>WhatsApp (com indicativo)</label><input required placeholder="258..." value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></div></div>
      <label>Fotografia (JPG, PNG ou WebP, máximo 5 MB)</label><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setImage(e.target.files?.[0]??null)}/>
      <h2>Escolhe o plano</h2>
      <div className="grid">{(Object.entries(PLANS) as [PlanId,typeof PLANS[PlanId]][]).map(([id,p])=><label className="card" key={id}><input type="radio" name="plan" checked={plan===id} onChange={()=>setPlan(id)} style={{width:"auto"}}/><b>{p.name}</b><p className="price">{p.price} MT</p><p>{p.days} dias</p></label>)}</div>
      <label>Referência do pagamento</label><input required maxLength={100} value={form.payment_reference} onChange={e=>setForm({...form,payment_reference:e.target.value})} placeholder="Referência fornecida pela operadora"/>
      <div className="notice">Depois de enviar, a equipa MOZ MARKET vai confirmar a transação e verificar o anúncio. Não envies PINs, códigos secretos ou palavras-passe.</div>
      <button disabled={busy}>{busy?"A enviar...":`Enviar pedido · ${PLANS[plan].price} MT`}</button>
    </form>
    {message&&<p className="notice">{message}</p>}
  </section>;
}
