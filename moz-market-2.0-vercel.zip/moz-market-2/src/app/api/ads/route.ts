import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { PLANS, PlanId } from "@/lib/plans";

const MAX_FILE = 5 * 1024 * 1024;
const TYPES = ["image/jpeg","image/png","image/webp"];

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({error:"É necessário entrar na conta."},{status:401});

    const form = await req.formData();
    const title = String(form.get("title")||"").trim();
    const category = String(form.get("category")||"").trim();
    const description = String(form.get("description")||"").trim();
    const phone = String(form.get("phone")||"").replace(/[^\d+]/g,"");
    const price = Number(form.get("price"));
    const reference = String(form.get("payment_reference")||"").trim();
    const plan = String(form.get("plan")||"basic") as PlanId;
    const image = form.get("image");

    if(!title || title.length>90 || !category || !description || description.length>1500 ||
       !Number.isFinite(price) || price<0 || !/^(\+?\d{9,15})$/.test(phone) ||
       !reference || reference.length>100 || !(plan in PLANS)) {
      return NextResponse.json({error:"Verifica os campos. Alguns dados estão inválidos."},{status:400});
    }

    let imagePath: string | null = null;
    if(image instanceof File && image.size>0){
      if(image.size>MAX_FILE || !TYPES.includes(image.type))
        return NextResponse.json({error:"Imagem inválida ou maior que 5 MB."},{status:400});
      const ext = image.type==="image/jpeg"?"jpg":image.type==="image/png"?"png":"webp";
      imagePath = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const {error: uploadError} = await supabase.storage.from("ad-images").upload(imagePath,image,{
        contentType:image.type,upsert:false
      });
      if(uploadError) return NextResponse.json({error:"Falha ao guardar a imagem."},{status:400});
    }

    const {error} = await supabase.from("ads").insert({
      seller_id:user.id,title,category,description,price,phone,
      plan_id:plan,amount_paid:PLANS[plan].price,
      payment_reference:reference,image_path:imagePath,status:"pending"
    });
    if(error) return NextResponse.json({error:"Não foi possível registar o anúncio. Tenta novamente."},{status:400});
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:"Erro inesperado."},{status:500});
  }
}
