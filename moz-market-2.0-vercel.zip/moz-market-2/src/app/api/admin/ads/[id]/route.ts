import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { PLANS, PlanId } from "@/lib/plans";

export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)return NextResponse.json({error:"Não autenticado."},{status:401});
 const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin")return NextResponse.json({error:"Acesso não autorizado."},{status:403});
 const {id}=await params;
 const body=await req.json();
 if(!["approve","reject"].includes(body.action))return NextResponse.json({error:"Ação inválida."},{status:400});
 const {data:ad,error:readError}=await supabase.from("ads").select("plan_id,status").eq("id",id).single();
 if(readError||!ad||ad.status!=="pending")return NextResponse.json({error:"Anúncio não encontrado ou já processado."},{status:404});
 const update:any={status:body.action==="approve"?"approved":"rejected"};
 if(body.action==="approve"){
  const plan=PLANS[ad.plan_id as PlanId];
  if(!plan)return NextResponse.json({error:"Plano inválido."},{status:400});
  update.approved_at=new Date().toISOString();
  update.expires_at=new Date(Date.now()+plan.days*86400000).toISOString();
 }
 const {error}=await supabase.from("ads").update(update).eq("id",id).eq("status","pending");
 if(error)return NextResponse.json({error:"Não foi possível atualizar."},{status:400});
 return NextResponse.json({ok:true});
}
