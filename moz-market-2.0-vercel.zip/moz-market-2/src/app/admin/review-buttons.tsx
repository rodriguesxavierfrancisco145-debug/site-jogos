"use client";
import { useState } from "react";
export default function ReviewButtons({id}:{id:string}){
 const [busy,setBusy]=useState(false),[msg,setMsg]=useState("");
 async function review(action:"approve"|"reject"){
  setBusy(true);setMsg("");
  const res=await fetch(`/api/admin/ads/${id}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action})});
  const data=await res.json();setBusy(false);
  if(!res.ok){setMsg(data.error||"Erro");return;}
  setMsg("Atualizado. Recarrega a página.");
 }
 return <div className="row"><button disabled={busy} onClick={()=>review("approve")}>Aprovar</button><button className="danger" disabled={busy} onClick={()=>review("reject")}>Rejeitar</button>{msg&&<span className="muted">{msg}</span>}</div>;
}
