import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import ReviewButtons from "./review-buttons";

export const revalidate=0;
export default async function Admin(){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user) redirect("/conta");
 const {data:profile}=await supabase.from("profiles").select("role").eq("id",user.id).single();
 if(profile?.role!=="admin") redirect("/");
 const {data:ads}=await supabase.from("ads").select("*").eq("status","pending").order("created_at");
 return <section><h1>🛡️ Administração MOZ MARKET</h1><p className="muted">Confirma pagamentos no painel oficial do fornecedor antes de aprovar.</p>
 {ads?.length?ads.map(a=><article className="card" key={a.id}><h2>{a.title}</h2><p>Vendedor: {a.seller_id}</p><p>Plano: {a.plan_id} · {a.amount_paid} MT</p><p>Referência: {a.payment_reference}</p><p>{a.description}</p>{a.image_path&&<p>Imagem armazenada: {a.image_path}</p>}<ReviewButtons id={a.id}/></article>):<div className="card">Não há pedidos pendentes.</div>}
 </section>;
}
