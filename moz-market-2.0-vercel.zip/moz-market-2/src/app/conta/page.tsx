"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function Account() {
  const supabase = createClient();
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [user,setUser] = useState<any>(null);
  const [ads,setAds] = useState<any[]>([]);
  const [message,setMessage] = useState("");

  async function load() {
    const {data:{user}} = await supabase.auth.getUser();
    setUser(user);
    if(user){
      const {data} = await supabase.from("ads").select("id,title,status,expires_at,created_at").eq("seller_id",user.id).order("created_at",{ascending:false});
      setAds(data ?? []);
    }
  }
  useEffect(()=>{load()},[]);

  async function signIn(e:React.FormEvent){
    e.preventDefault(); setMessage("");
    const {error}=await supabase.auth.signInWithPassword({email,password});
    if(error) setMessage(error.message); else await load();
  }
  async function signUp(e:React.FormEvent){
    e.preventDefault(); setMessage("");
    const {error}=await supabase.auth.signUp({email,password});
    if(error) setMessage(error.message);
    else setMessage("Conta criada. Confirma o teu email se a confirmação estiver ativa e depois entra.");
  }
  async function logout(){await supabase.auth.signOut();setUser(null);setAds([])}
  if(!user) return <section className="card" style={{maxWidth:520,margin:"35px auto"}}>
    <h1>👤 Conta do vendedor</h1><p className="muted">Entra ou cria uma conta para gerir os teus anúncios.</p>
    <form onSubmit={signIn}><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>Palavra-passe</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required/><button>Entrar</button></form>
    <button className="secondary" onClick={signUp}>Criar conta</button>
    {message&&<p className="notice">{message}</p>}
  </section>;
  return <section className="card">
    <div className="row"><div><h1>Olá, vendedor!</h1><p className="muted">{user.email}</p></div><button className="secondary" onClick={logout}>Sair</button></div>
    <p><Link className="button" href="/publicar">+ Novo anúncio</Link></p>
    <h2>Os meus anúncios</h2>
    {ads.length ? ads.map(a=><div className="card" key={a.id}><b>{a.title}</b><p>Estado: <span className="pill">{a.status}</span></p><p className="muted">Expira: {a.expires_at?new Date(a.expires_at).toLocaleString("pt-PT"):"Após aprovação"}</p></div>) : <p>Ainda não publicaste anúncios.</p>}
  </section>;
}
