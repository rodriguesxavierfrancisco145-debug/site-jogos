import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export const revalidate = 0;

export default async function Home() {
  const supabase = await createClient();
  const { data: ads } = await supabase
    .from("ads")
    .select("id,title,description,price,category,image_path,expires_at")
    .eq("status", "approved")
    .gt("expires_at", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(30);

  const cards = await Promise.all((ads ?? []).map(async (ad) => {
    let imageUrl = "";
    if (ad.image_path) {
      const { data } = await supabase.storage.from("ad-images").createSignedUrl(ad.image_path, 3600);
      imageUrl = data?.signedUrl ?? "";
    }
    return { ...ad, imageUrl };
  }));

  return <div>
    <section className="hero">
      <h1>O mercado digital de Moçambique 🇲🇿</h1>
      <p>Encontra produtos, serviços e negócios perto de ti. Publica o teu anúncio depois de escolher um plano e concluir a verificação.</p>
      <Link className="button" href="/publicar">+ Publicar anúncio</Link>
    </section>
    <div className="row">
      <div><h2>Anúncios disponíveis</h2><p className="muted">Apenas anúncios aprovados e dentro do prazo aparecem aqui.</p></div>
      <Link className="button secondary" href="/conta">Área do vendedor</Link>
    </div>
    <section className="grid">
      {cards.length ? cards.map(ad => <article className="card listing" key={ad.id}>
        {ad.imageUrl ? <img src={ad.imageUrl} alt={ad.title}/> : <div style={{height:175,background:"#eee",borderRadius:9,display:"grid",placeItems:"center"}}>📦 MOZ MARKET</div>}
        <p className="muted">{ad.category}</p><h3>{ad.title}</h3>
        <p>{ad.description.slice(0,120)}{ad.description.length>120?"…":""}</p>
        <p className="price">{Number(ad.price).toLocaleString("pt-MZ")} MT</p>
      </article>) : <div className="card">Ainda não há anúncios publicados. Sê um dos primeiros vendedores!</div>}
    </section>
  </div>;
}
